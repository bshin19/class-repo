javac -cp ../../ *.java
java -cp ../../ com.streams.Streams
