package com.exceptions;

class Test {

  public static void main (String args[]) {
    // Your code here.
  }

}
