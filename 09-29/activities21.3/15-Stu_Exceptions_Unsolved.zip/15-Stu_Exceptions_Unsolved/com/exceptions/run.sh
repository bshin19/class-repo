javac -cp ../../ *.java
java -cp ../../ com.exceptions.Test
