package com.streams;

import java.util.Arrays;

import java.util.ArrayList;

import java.util.stream.Stream;

import java.util.Scanner;

class Streams {

  // Remember, you create a Scanner with new Scanner(System.in).

  public static void main (String[] args) {
    // Your code here.
  }

}
