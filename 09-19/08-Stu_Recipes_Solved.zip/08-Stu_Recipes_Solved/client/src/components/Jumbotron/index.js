export { default } from "./Jumbotron";
