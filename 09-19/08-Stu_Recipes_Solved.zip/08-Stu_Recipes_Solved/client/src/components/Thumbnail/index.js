export { default } from "./Thumbnail";
